package leshugan.yg;

import android.content.Intent;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.media.MediaMetadataRetriever;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.view.Window;
import android.view.View;
import android.graphics.Color;
import android.os.Build;
import android.os.StrictMode;
import android.os.Environment;
import android.provider.Settings;
import android.util.Base64;
import android.util.Size;
import android.os.Handler;
import android.os.Looper;
import android.database.ContentObserver;
import android.database.Cursor;
import android.provider.MediaStore;

import androidx.core.content.FileProvider;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;

@CapacitorPlugin(name = "Apps")
public class AppsPlugin extends Plugin {

    private ContentObserver mediaObserver;
    @Override
    public void load() {
        try {
            Handler h = new Handler(Looper.getMainLooper());
            mediaObserver = new ContentObserver(h) {
                private long last = 0;
                @Override public void onChange(boolean self) {
                    long now = System.currentTimeMillis();
                    if (now - last < 1500) return; last = now;   // дебаунс
                    notifyListeners("mediaChanged", new JSObject());
                }
            };
            getContext().getContentResolver().registerContentObserver(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, true, mediaObserver);
            getContext().getContentResolver().registerContentObserver(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true, mediaObserver);
        } catch (Throwable ignored) {}
    }

    private static final String IMG = "jpg|jpeg|png|webp|gif|bmp|heic|heif";
    private static final String VID = "mp4|mkv|avi|mov|webm|3gp|m4v|ts";

    private boolean isImg(String n) { return n.toLowerCase().matches(".*\\.(" + IMG + ")$"); }
    private boolean isVid(String n) { return n.toLowerCase().matches(".*\\.(" + VID + ")$"); }

    // ===== Рекурсивное сканирование медиа за ОДИН проход.
    //   .nomedia  — папка и все её подпапки скрыты (уходят в раздел «Скрытые»).
    //   .nofolder — игнорируются только файлы этой папки, подпапки сканируются как обычно.
    @PluginMethod
    public void scanMedia(PluginCall call) {
        final String mode = call.getString("mode", "visible");
        // в фоновом потоке — чтобы не блокировать UI
        new Thread(() -> {
            try {
                File root = Environment.getExternalStorageDirectory();
                JSArray out = new JSArray();
                if ("hidden".equals(mode)) {
                    walk(root, false, true, out, 0);            // скрытые: MediaStore их не индексирует (.nomedia)
                } else if ("fs".equals(mode)) {
                    walk(root, false, false, out, 0);           // сверка с ФС: то, что MediaStore ещё не проиндексировал
                } else {
                    queryStore(out, false);                     // фото
                    queryStore(out, true);                      // видео
                    if (out.length() == 0) walk(root, false, false, out, 0); // подстраховка
                }
                JSObject ret = new JSObject();
                ret.put("items", out);
                ret.put("root", root.getAbsolutePath());
                call.resolve(ret);
            } catch (Exception e) { call.reject(e.getMessage()); }
        }).start();
    }

    // ===== Быстрый скан через MediaStore: системная база уже содержит путь, размер, дату,
    //       ширину/высоту и длительность — файлы не открываются вообще. =====
    private void queryStore(JSArray out, boolean video) {
        Cursor c = null;
        java.util.HashMap<String, Boolean> noFolderCache = new java.util.HashMap<>();
        try {
            Uri uri = video ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
            String[] cols = video
                ? new String[]{ MediaStore.MediaColumns.DATA, MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.DATE_MODIFIED, MediaStore.MediaColumns.WIDTH, MediaStore.MediaColumns.HEIGHT, MediaStore.Video.VideoColumns.DURATION }
                : new String[]{ MediaStore.MediaColumns.DATA, MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.DATE_MODIFIED, MediaStore.MediaColumns.WIDTH, MediaStore.MediaColumns.HEIGHT, MediaStore.Images.ImageColumns.ORIENTATION };
            c = getContext().getContentResolver().query(uri, cols, null, null, null);
            if (c == null) return;
            int iData = c.getColumnIndex(MediaStore.MediaColumns.DATA);
            int iSize = c.getColumnIndex(MediaStore.MediaColumns.SIZE);
            int iDate = c.getColumnIndex(MediaStore.MediaColumns.DATE_MODIFIED);
            int iW = c.getColumnIndex(MediaStore.MediaColumns.WIDTH);
            int iH = c.getColumnIndex(MediaStore.MediaColumns.HEIGHT);
            int iExtra = video ? c.getColumnIndex(MediaStore.Video.VideoColumns.DURATION) : c.getColumnIndex(MediaStore.Images.ImageColumns.ORIENTATION);
            while (c.moveToNext()) {
                String path = iData >= 0 ? c.getString(iData) : null;
                if (path == null || path.isEmpty()) continue;
                if (path.contains("/.")) continue;                                  // скрытые папки/файлы
                if (path.contains("/Android/data/") || path.contains("/Android/obb/")) continue;
                String name = path.substring(path.lastIndexOf('/') + 1);
                if (video ? !isVid(name) : !isImg(name)) continue;
                File k = new File(path);
                if (!k.exists()) continue;                                          // призраки удалённых файлов
                String bucketPath = path.substring(0, Math.max(0, path.lastIndexOf('/')));
                Boolean nf = noFolderCache.get(bucketPath);
                if (nf == null) { nf = new File(bucketPath, ".nofolder").exists(); noFolderCache.put(bucketPath, nf); }
                if (nf) continue;                                                   // .nofolder — файлы этой папки не показываем
                JSObject o = new JSObject();
                o.put("uri", "file://" + path);
                o.put("name", name);
                o.put("size", iSize >= 0 ? c.getLong(iSize) : k.length());
                long dm = iDate >= 0 ? c.getLong(iDate) * 1000L : 0;
                o.put("mtime", dm > 0 ? dm : k.lastModified());
                o.put("video", video);
                o.put("bucketPath", bucketPath);
                o.put("bucketName", bucketPath.substring(bucketPath.lastIndexOf('/') + 1));
                o.put("thumb", new File(thumbDir(), thumbKey(k) + ".jpg").getAbsolutePath());
                int w = iW >= 0 ? c.getInt(iW) : 0, h = iH >= 0 ? c.getInt(iH) : 0;
                if (!video && iExtra >= 0) { int deg = c.getInt(iExtra); if (deg == 90 || deg == 270) { int t = w; w = h; h = t; } }
                if (w > 0 && h > 0) { o.put("w", w); o.put("h", h); }
                if (video && iExtra >= 0) { long d = c.getLong(iExtra); if (d > 0) o.put("dur", d); }
                out.put(o);
            }
        } catch (Throwable ignored) {
        } finally { if (c != null) try { c.close(); } catch (Throwable ignored) {} }
    }

    // ===== Кэш списка медиа на диске (приватная папка приложения, без лимитов localStorage) =====
    private File cacheFile(String key) { String k = (key == null || key.isEmpty()) ? "media" : key.replaceAll("[^a-zA-Z0-9_]", "_"); File d = getContext().getExternalFilesDir(null); if (d == null) d = getContext().getFilesDir(); return new File(d, "cache_" + k + ".json"); }

    @PluginMethod
    public void cacheGet(PluginCall call) {
        try {
            File f = cacheFile(call.getString("key", "media"));
            JSObject ret = new JSObject();
            if (f.exists()) ret.put("data", new String(readAll(new FileInputStream(f)), "UTF-8"));
            call.resolve(ret);
        } catch (Exception e) { call.resolve(new JSObject()); }
    }

    @PluginMethod
    public void cacheSet(PluginCall call) {
        final String data = call.getString("data", "");
        final String key = call.getString("key", "media");
        new Thread(() -> {
            try { FileOutputStream o = new FileOutputStream(cacheFile(key)); o.write(data.getBytes("UTF-8")); o.close(); } catch (Exception ignored) {}
            call.resolve(new JSObject());
        }).start();
    }

    private void walk(File dir, boolean insideNomedia, boolean wantHidden, JSArray out, int depth) {
        if (dir == null || depth > 12) return;
        File[] kids = dir.listFiles();
        if (kids == null) return;
        boolean branchHidden = insideNomedia || new File(dir, ".nomedia").exists();
        // в обычном режиме НЕ заходим в скрытые ветки вовсе — это даёт мгновенный старт
        if (!wantHidden && branchHidden) return;
        boolean noFolder = new File(dir, ".nofolder").exists(); // игнор файлов только этой папки
        for (File k : kids) {
            String name = k.getName();
            if (name.startsWith(".")) continue;             // служебные/скрытые папки и файлы не трогаем
            if (k.isDirectory()) {
                String dn = k.getName();
                if (dir.getName().equals("Android") && (dn.equals("data") || dn.equals("obb"))) continue; // огромные/недоступные ветки
                walk(k, branchHidden, wantHidden, out, depth + 1);
            } else {
                boolean vid = isVid(name);
                if (!isImg(name) && !vid) continue;
                if (wantHidden && !branchHidden) continue;   // режим скрытых: только из .nomedia-веток
                if (!branchHidden && noFolder) continue;     // .nofolder — пропускаем файлы этой папки
                File p = k.getParentFile();
                JSObject o = new JSObject();
                o.put("uri", "file://" + k.getAbsolutePath());
                o.put("name", name);
                o.put("size", k.length());
                o.put("mtime", k.lastModified());
                o.put("video", vid);
                o.put("bucketPath", p != null ? p.getAbsolutePath() : "");
                o.put("bucketName", p != null ? p.getName() : "");
                o.put("thumb", new File(thumbDir(), thumbKey(k) + ".jpg").getAbsolutePath());
                out.put(o);
            }
        }
    }

    // ===== Простой список файлов в папке (для корзины) =====
    @PluginMethod
    public void list(PluginCall call) {
        String uriStr = call.getString("uri");
        if (uriStr == null) { call.reject("no uri"); return; }
        try {
            File dir = toFile(uriStr);
            File[] kids = dir.listFiles();
            JSArray arr = new JSArray();
            if (kids != null) for (File k : kids) {
                if (k.isDirectory()) continue;
                JSObject o = new JSObject();
                o.put("uri", "file://" + k.getAbsolutePath());
                o.put("name", k.getName());
                o.put("size", k.length());
                o.put("mtime", k.lastModified());
                o.put("video", isVid(k.getName()));
                o.put("thumb", new File(thumbDir(), thumbKey(k) + ".jpg").getAbsolutePath());
                putMeta(o, k, isVid(k.getName()));
                arr.put(o);
            }
            JSObject ret = new JSObject(); ret.put("files", arr); call.resolve(ret);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    // ===== Превью (фото и видео), кэш на диске =====
    private File thumbDir() {
        File d = new File(getContext().getCacheDir(), "thumbs");
        if (!d.exists()) d.mkdirs();
        return d;
    }
    private String thumbKey(File src) {
        String base = src.getAbsolutePath() + "|" + src.lastModified() + "|" + src.length();
        return Integer.toHexString(base.hashCode()) + "_" + src.lastModified();
    }

    // генерирует превью в кэш (если нет) и возвращает файл кэша, либо null
    private File ensureThumb(File f) {
        try {
            if (f == null || !f.exists()) return null;
            File cacheFile = new File(thumbDir(), thumbKey(f) + ".jpg");
            if (cacheFile.exists()) return cacheFile;
            String name = f.getName().toLowerCase();
            Bitmap b = null;
            if (isImg(name)) {
                if (Build.VERSION.SDK_INT >= 29) {
                    try { b = ThumbnailUtils.createImageThumbnail(f, new Size(512, 512), null); } catch (Throwable ignored) {}
                }
                if (b == null) {
                    android.graphics.BitmapFactory.Options o = new android.graphics.BitmapFactory.Options();
                    o.inJustDecodeBounds = true;
                    android.graphics.BitmapFactory.decodeFile(f.getAbsolutePath(), o);
                    int s = 1; while (o.outWidth / s > 1024 || o.outHeight / s > 1024) s *= 2;
                    android.graphics.BitmapFactory.Options o2 = new android.graphics.BitmapFactory.Options();
                    o2.inSampleSize = s;
                    b = android.graphics.BitmapFactory.decodeFile(f.getAbsolutePath(), o2);
                    b = applyExif(b, f.getAbsolutePath());
                }
            } else if (isVid(name)) {
                try { b = ThumbnailUtils.createVideoThumbnail(f.getAbsolutePath(), android.provider.MediaStore.Images.Thumbnails.MINI_KIND); } catch (Throwable ignored) {}
                if (b == null) {
                    MediaMetadataRetriever r = new MediaMetadataRetriever();
                    try { r.setDataSource(f.getAbsolutePath()); b = r.getFrameAtTime(1000000); } catch (Throwable ignored) {}
                    try { r.release(); } catch (Throwable ignored) {}
                }
            }
            if (b == null) return null;
            int mx = Math.max(b.getWidth(), b.getHeight());
            if (mx > 512) { float sc = 512f / mx; b = Bitmap.createScaledBitmap(b, Math.round(b.getWidth() * sc), Math.round(b.getHeight() * sc), true); }
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            b.compress(Bitmap.CompressFormat.JPEG, 86, out);
            OutputStream fos = new FileOutputStream(cacheFile); fos.write(out.toByteArray()); fos.close();
            return cacheFile;
        } catch (Throwable t) { return null; }
    }

    @PluginMethod
    public void thumb(PluginCall call) {
        String uriStr = call.getString("uri");
        if (uriStr == null) { call.reject("no uri"); return; }
        try {
            File cacheFile = ensureThumb(toFile(uriStr));
            JSObject ret = new JSObject();
            if (cacheFile == null || !cacheFile.exists()) { call.resolve(ret); return; }
            byte[] data = readAll(new FileInputStream(cacheFile));
            ret.put("thumb", "data:image/jpeg;base64," + Base64.encodeToString(data, Base64.NO_WRAP));
            try { android.graphics.BitmapFactory.Options bo = new android.graphics.BitmapFactory.Options(); bo.inJustDecodeBounds = true; android.graphics.BitmapFactory.decodeFile(cacheFile.getAbsolutePath(), bo); ret.put("w", bo.outWidth); ret.put("h", bo.outHeight); } catch (Exception ignored) {}
            call.resolve(ret);
        } catch (Exception e) { call.resolve(new JSObject()); }
    }

    // фоновый прогрев превью (чтобы альбомы открывались мгновенно)
    private java.util.concurrent.ExecutorService warmPool;
    @PluginMethod
    public void writeFile(PluginCall call) {
        String path = call.getString("path");
        String data = call.getString("data");   // base64 (без префикса)
        if (path == null || data == null) { call.reject("no path/data"); return; }
        try {
            File f = new File(path);
            if (f.getParentFile() != null && !f.getParentFile().exists()) f.getParentFile().mkdirs();
            if (f.exists()) f = uniqueName(f);
            byte[] bytes = Base64.decode(data, Base64.DEFAULT);
            OutputStream o = new FileOutputStream(f); o.write(bytes); o.close();
            JSObject ret = new JSObject(); ret.put("uri", "file://" + f.getAbsolutePath()); ret.put("path", f.getAbsolutePath()); call.resolve(ret);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void warmThumbs(PluginCall call) {
        JSArray a = call.getArray("uris");
        final java.util.List<String> uris = new java.util.ArrayList<>();
        if (a != null) { try { for (Object o : a.toList()) uris.add(String.valueOf(o)); } catch (Exception ignored) {} }
        call.resolve();
        if (warmPool != null) { warmPool.shutdownNow(); }
        int cores = Runtime.getRuntime().availableProcessors();
        int n = Math.max(1, Math.min(4, cores - 2));
        warmPool = java.util.concurrent.Executors.newFixedThreadPool(n);
        for (final String u : uris) {
            warmPool.execute(() -> {
                if (Thread.currentThread().isInterrupted()) return;
                try { ensureThumb(toFile(u)); } catch (Throwable ignored) {}
            });
        }
        warmPool.shutdown();
    }

    // ===== Удалить (насовсем) =====
    @PluginMethod
    public void delete(PluginCall call) {
        String uriStr = call.getString("uri");
        if (uriStr == null) { call.reject("no uri"); return; }
        File f = toFile(uriStr);
        boolean ok = deleteRecursive(f);
        JSObject ret = new JSObject(); ret.put("deleted", ok || !f.exists()); call.resolve(ret);
    }

    // ===== Переместить (в корзину / восстановить). Создаёт целевые папки. =====
    @PluginMethod
    private File uniqueName(File f) {
        String n = f.getName(); int dot = n.lastIndexOf('.');
        String base = dot > 0 ? n.substring(0, dot) : n, ext = dot > 0 ? n.substring(dot) : "";
        for (int i = 1; i < 9999; i++) { File c = new File(f.getParentFile(), base + " (" + i + ")" + ext); if (!c.exists()) return c; }
        return f;
    }
    private int exifDeg(String path) {
        try {
            android.media.ExifInterface ex = new android.media.ExifInterface(path);
            int o = ex.getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1);
            if (o == 6) return 90; if (o == 3) return 180; if (o == 8) return 270;
        } catch (Throwable ignored) {}
        return 0;
    }
    // размеры (с учётом поворота) и длительность видео — чтобы мозаика не прыгала и показывать длительность
    private void putMeta(JSObject o, File k, boolean vid) {
        try {
            if (vid) {
                MediaMetadataRetriever r = new MediaMetadataRetriever();
                try {
                    r.setDataSource(k.getAbsolutePath());
                    int w = pInt(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH));
                    int h = pInt(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT));
                    int rot = pInt(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION));
                    long dur = pLong(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION));
                    if (rot == 90 || rot == 270) { int t = w; w = h; h = t; }
                    if (w > 0 && h > 0) { o.put("w", w); o.put("h", h); }
                    if (dur > 0) o.put("dur", dur);
                } finally { try { r.release(); } catch (Throwable ignored) {} }
            } else {
                android.graphics.BitmapFactory.Options bo = new android.graphics.BitmapFactory.Options();
                bo.inJustDecodeBounds = true;
                android.graphics.BitmapFactory.decodeFile(k.getAbsolutePath(), bo);
                int w = bo.outWidth, h = bo.outHeight, deg = exifDeg(k.getAbsolutePath());
                if (deg == 90 || deg == 270) { int t = w; w = h; h = t; }
                if (w > 0 && h > 0) { o.put("w", w); o.put("h", h); }
            }
        } catch (Throwable ignored) {}
    }
    private int pInt(String s) { try { return Integer.parseInt(s.trim()); } catch (Throwable t) { return 0; } }
    private long pLong(String s) { try { return Long.parseLong(s.trim()); } catch (Throwable t) { return 0; } }

    private void deleteViaMediaStore(File f) {
        try { getContext().getContentResolver().delete(MediaStore.Files.getContentUri("external"), MediaStore.Files.FileColumns.DATA + "=?", new String[]{ f.getAbsolutePath() }); } catch (Throwable ignored) {}
        try { getContext().sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(f))); } catch (Throwable ignored) {}
    }
    private File trashDirF() { File base = getContext().getExternalFilesDir(null); if (base == null) base = getContext().getFilesDir(); File d = new File(base, ".trash"); if (!d.exists()) d.mkdirs(); return d; }
    @PluginMethod
    public void trashPut(PluginCall call) {
        String from = call.getString("from"); if (from == null) { call.reject("no from"); return; }
        try {
            File src = toFile(from);
            String tname = System.currentTimeMillis() + "_" + Math.abs(from.hashCode()) + "__" + src.getName();
            File dst = new File(trashDirF(), tname);
            boolean ok = src.renameTo(dst);
            if (!ok) {
                FileInputStream in = new FileInputStream(src); FileOutputStream o = new FileOutputStream(dst);
                byte[] b = new byte[65536]; int r; while ((r = in.read(b)) > 0) o.write(b, 0, r); in.close(); o.close();
                if (!src.delete()) deleteViaMediaStore(src);
                ok = dst.exists();
            }
            JSObject ret = new JSObject(); ret.put("ok", ok); ret.put("uri", "file://" + dst.getAbsolutePath()); ret.put("name", tname); call.resolve(ret);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }
    @PluginMethod
    public void trashList(PluginCall call) {
        JSArray arr = new JSArray();
        try { File[] ks = trashDirF().listFiles(); if (ks != null) for (File k : ks) { if (k.isDirectory()) continue; JSObject o = new JSObject(); o.put("uri", "file://" + k.getAbsolutePath()); o.put("name", k.getName()); o.put("size", k.length()); o.put("mtime", k.lastModified()); o.put("video", isVid(k.getName())); o.put("thumb", new File(thumbDir(), thumbKey(k) + ".jpg").getAbsolutePath()); putMeta(o, k, isVid(k.getName())); arr.put(o); } } catch (Throwable ignored) {}
        JSObject ret = new JSObject(); ret.put("files", arr); call.resolve(ret);
    }
    @PluginMethod
    public void sysPaths(PluginCall call) {
        JSObject ret = new JSObject();
        try {
            File base = getContext().getExternalFilesDir(null);
            if (base == null) base = getContext().getFilesDir();
            File tr = new File(base, ".trash"); if (!tr.exists()) tr.mkdirs();
            ret.put("trash", tr.getAbsolutePath());
        } catch (Throwable ignored) {}
        try { ret.put("root", Environment.getExternalStorageDirectory().getAbsolutePath()); } catch (Throwable ignored) {}
        call.resolve(ret);
    }
    public void move(PluginCall call) {
        String from = call.getString("from");
        String to = call.getString("to");
        if (from == null || to == null) { call.reject("no from/to"); return; }
        try {
            File src = toFile(from);
            File dst = toFile(to);
            File parent = dst.getParentFile();
            if (parent != null && !parent.exists()) parent.mkdirs();
            if (dst.exists()) dst = uniqueName(dst);
            boolean ok = src.renameTo(dst);
            if (!ok) {                                  // копируем и удаляем оригинал (File.delete/renameTo часто не проходят для медиа)
                FileInputStream in = new FileInputStream(src);
                FileOutputStream o = new FileOutputStream(dst);
                byte[] buf = new byte[65536]; int r;
                while ((r = in.read(buf)) > 0) o.write(buf, 0, r);
                in.close(); o.close();
                ok = src.delete();
            }
            JSObject ret = new JSObject(); ret.put("ok", ok); ret.put("uri", "file://" + dst.getAbsolutePath()); call.resolve(ret);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    // ===== Создать .nomedia (скрыть альбом) / удалить .nomedia (показать) =====
    @PluginMethod
    public void setNomedia(PluginCall call) {
        String path = call.getString("path");
        boolean on = Boolean.TRUE.equals(call.getBoolean("on", true));
        if (path == null) { call.reject("no path"); return; }
        try {
            File dir = toFile(path);
            File nm = new File(dir, ".nomedia");
            if (on) { if (!nm.exists()) new FileOutputStream(nm).close(); }
            else { if (nm.exists()) nm.delete(); }
            JSObject ret = new JSObject(); ret.put("ok", true); call.resolve(ret);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    // ===== Поделиться =====
    @PluginMethod
    public void share(PluginCall call) {
        String uriStr = call.getString("uri");
        String mime = call.getString("mime", "image/*");
        if (uriStr == null) { call.reject("no uri"); return; }
        try {
            File f = toFile(uriStr);
            if (!f.exists()) { call.reject("Файл не найден"); return; }
            Uri u = providerUri(f);
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType(mime);
            i.putExtra(Intent.EXTRA_STREAM, u);
            i.setClipData(android.content.ClipData.newRawUri("", u));
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Intent ch = Intent.createChooser(i, "Поделиться");
            ch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(ch);
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    // ===== Редактировать через стороннее приложение =====
    @PluginMethod
    public void editImage(PluginCall call) {
        String uriStr = call.getString("uri");
        String mime = call.getString("mime", "image/*");
        if (uriStr == null) { call.reject("no uri"); return; }
        try {
            File f = toFile(uriStr);
            if (!f.exists()) { call.reject("Файл не найден"); return; }
            Uri u = providerUri(f);
            Intent i = new Intent(Intent.ACTION_EDIT);
            i.setDataAndType(u, mime);
            i.setClipData(android.content.ClipData.newRawUri("", u));
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            Intent ch = Intent.createChooser(i, "Изменить через");
            ch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(ch);
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    // ===== Установить как обои (системный выбор: экран/блокировка) =====
    @PluginMethod
    public void setWallpaper(PluginCall call) {
        String uriStr = call.getString("uri");
        if (uriStr == null) { call.reject("no uri"); return; }
        try {
            File f = toFile(uriStr);
            if (!f.exists()) { call.reject("Файл не найден"); return; }
            Uri u = providerUri(f);
            Intent i = new Intent(Intent.ACTION_ATTACH_DATA);
            i.addCategory(Intent.CATEGORY_DEFAULT);
            i.setDataAndType(u, "image/*");
            i.putExtra("mimeType", "image/*");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Intent ch = Intent.createChooser(i, "Установить как обои");
            ch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(ch);
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    private Bitmap applyExif(Bitmap b, String path) {
        if (b == null) return null;
        try {
            android.media.ExifInterface ex = new android.media.ExifInterface(path);
            int o = ex.getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, android.media.ExifInterface.ORIENTATION_NORMAL);
            int deg = 0;
            if (o == android.media.ExifInterface.ORIENTATION_ROTATE_90) deg = 90;
            else if (o == android.media.ExifInterface.ORIENTATION_ROTATE_180) deg = 180;
            else if (o == android.media.ExifInterface.ORIENTATION_ROTATE_270) deg = 270;
            if (deg != 0) {
                android.graphics.Matrix m = new android.graphics.Matrix();
                m.postRotate(deg);
                b = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), m, true);
            }
        } catch (Throwable ignored) {}
        return b;
    }

    // Входящий URI («Открыть с помощью»): file:// — берём как есть, content:// — ищем реальный путь,
    // а если провайдер его не отдаёт (например, файл распакован из архива) — копируем в кэш.
    private String incomingName(Uri u) {
        try {
            Cursor c = getContext().getContentResolver().query(u, new String[]{ MediaStore.MediaColumns.DISPLAY_NAME }, null, null, null);
            if (c != null) { try { if (c.moveToFirst()) { String n = c.getString(0); if (n != null && !n.isEmpty()) return n; } } finally { c.close(); } }
        } catch (Throwable ignored) {}
        String p = u.getLastPathSegment();
        return p != null && p.contains("/") ? p.substring(p.lastIndexOf('/') + 1) : p;
    }

    private File resolveIncoming(Uri u, String type) {
        try {
            if ("file".equals(u.getScheme())) { File f = new File(u.getPath()); return (f.exists() && f.canRead()) ? f : null; }
            // реальный путь берём только если он доступен нам на чтение (у чужого приватного каталога — нет)
            try {
                Cursor c = getContext().getContentResolver().query(u, new String[]{ MediaStore.MediaColumns.DATA }, null, null, null);
                if (c != null) {
                    try { if (c.moveToFirst() && c.getColumnCount() > 0) { String p = c.getString(0); if (p != null && !p.isEmpty()) { File f = new File(p); if (f.exists() && f.canRead()) return f; } } }
                    finally { c.close(); }
                }
            } catch (Throwable ignored) {}
            // иначе копируем поток в кэш; имя латиницей — путь с пробелами и кириллицей WebView не открывает
            String nm = incomingName(u);
            String ext = "";
            if (nm != null && nm.lastIndexOf('.') > 0) ext = nm.substring(nm.lastIndexOf('.') + 1).toLowerCase();
            if (ext.isEmpty() || ext.length() > 5) ext = (type != null && type.startsWith("video")) ? "mp4" : "jpg";
            File dir = new File(getContext().getCacheDir(), "incoming");
            if (!dir.exists()) dir.mkdirs();
            for (File old : dir.listFiles() != null ? dir.listFiles() : new File[0]) old.delete();
            File out = new File(dir, "incoming_" + System.currentTimeMillis() + "." + ext);
            InputStream in = getContext().getContentResolver().openInputStream(u);
            if (in == null) return null;
            OutputStream o = new FileOutputStream(out);
            byte[] b = new byte[65536]; int r;
            while ((r = in.read(b)) > 0) o.write(b, 0, r);
            in.close(); o.close();
            return out.exists() && out.length() > 0 ? out : null;
        } catch (Throwable t) { return null; }
    }

    @PluginMethod
    public void getLaunchMode(PluginCall call) {
        JSObject ret = new JSObject();
        try {
            Activity act = getActivity();
            Intent it = act != null ? act.getIntent() : null;
            String action = it != null ? it.getAction() : null;
            boolean pick = Intent.ACTION_GET_CONTENT.equals(action) || Intent.ACTION_PICK.equals(action);
            String type = it != null ? it.getType() : null;
            if (it != null && (type == null || type.startsWith("vnd.android.cursor"))) {
                // ACTION_PICK часто идёт без mime: тип берём из data-URI (content://media/external/images|video/...)
                String d = it.getData() != null ? it.getData().toString() : "";
                String t = type != null ? type : "";
                if (d.contains("/video") || t.contains("/video")) type = "video/*";
                else if (d.contains("/images") || t.contains("/image")) type = "image/*";
                else type = null;
            }
            ret.put("pick", pick);
            ret.put("mime", type != null ? type : "*/*");
            ret.put("multiple", it != null && it.getBooleanExtra(Intent.EXTRA_ALLOW_MULTIPLE, false));
            // нас позвали посмотреть конкретный файл («Открыть с помощью»)
            boolean view = Intent.ACTION_VIEW.equals(action) && it != null && it.getData() != null;
            ret.put("view", view);
            if (view) {
                File f = resolveIncoming(it.getData(), it.getType());
                if (f != null) {
                    String nm = incomingName(it.getData());
                    if (nm == null || nm.isEmpty()) nm = f.getName();
                    ret.put("uri", "file://" + f.getAbsolutePath());
                    ret.put("name", nm);
                    ret.put("size", f.length());
                    ret.put("mtime", f.lastModified());
                    boolean vid = isVid(nm) || isVid(f.getName()) || (it.getType() != null && it.getType().startsWith("video"));
                    ret.put("isVideo", vid);
                    try { act.setIntent(new Intent(Intent.ACTION_MAIN)); } catch (Throwable ignored) {}
                } else ret.put("view", false);
            }
        } catch (Throwable ignored) {}
        call.resolve(ret);
    }
    @PluginMethod
    public void pickResult(PluginCall call) {
        JSArray arr = call.getArray("uris");
        java.util.List<String> list = new java.util.ArrayList<>();
        try { if (arr != null) for (Object o : arr.toList()) list.add(String.valueOf(o)); } catch (Exception ignored) {}
        String one = call.getString("uri");
        if (list.isEmpty() && one != null) list.add(one);
        if (list.isEmpty()) { call.reject("no uri"); return; }
        try {
            Intent res = new Intent();
            android.content.ClipData clip = null;
            for (int i = 0; i < list.size(); i++) {
                Uri content = providerUri(toFile(list.get(i)));
                if (i == 0) { res.setData(content); clip = android.content.ClipData.newRawUri("", content); }
                else clip.addItem(new android.content.ClipData.Item(content));
            }
            if (list.size() > 1) res.setClipData(clip);
            res.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Activity act = getActivity();
            if (act != null) { act.setResult(Activity.RESULT_OK, res); act.finish(); }
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }
    @PluginMethod
    public void pickCancel(PluginCall call) {
        try {
            Activity act = getActivity();
            if (act != null) { act.setResult(Activity.RESULT_CANCELED); act.finish(); }
        } catch (Throwable ignored) {}
        call.resolve();
    }
    private Uri providerUri(File f) {
        try { return FileProvider.getUriForFile(getContext(), getContext().getPackageName() + ".appsfp", f); }
        catch (Exception e) {
            try { StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build()); } catch (Exception ignored) {}
            return Uri.fromFile(f);
        }
    }

    // ===== Цвет статус-бара/навбара под тему =====
    @PluginMethod
    public void setBars(PluginCall call) {
        final String color = call.getString("color", "#000000");
        final boolean light = Boolean.TRUE.equals(call.getBoolean("light", false));
        try {
            getActivity().runOnUiThread(() -> {
                try {
                    Window w = getActivity().getWindow();
                    int c = Color.parseColor(color);
                    w.setStatusBarColor(c);
                    w.setNavigationBarColor(c);
                    View dv = w.getDecorView();
                    int flags = dv.getSystemUiVisibility();
                    if (Build.VERSION.SDK_INT >= 23) { if (light) flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR; else flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR; }
                    if (Build.VERSION.SDK_INT >= 26) { if (light) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR; else flags &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR; }
                    dv.setSystemUiVisibility(flags);
                } catch (Exception ignored) {}
            });
        } catch (Exception ignored) {}
        call.resolve();
    }

    // ===== Доступ ко всем файлам =====
    @PluginMethod
    public void hasAllFiles(PluginCall call) {
        boolean granted = Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager();
        JSObject ret = new JSObject(); ret.put("granted", granted); call.resolve(ret);
    }

    @PluginMethod
    public void requestAllFiles(PluginCall call) {
        try {
            Intent i;
            if (Build.VERSION.SDK_INT >= 30) {
                i = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                i.setData(Uri.parse("package:" + getContext().getPackageName()));
            } else {
                i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                i.setData(Uri.parse("package:" + getContext().getPackageName()));
            }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    // ===== helpers =====
    private boolean deleteRecursive(File f) {
        if (f.isDirectory()) { File[] kids = f.listFiles(); if (kids != null) for (File k : kids) deleteRecursive(k); }
        return f.delete();
    }
    private File toFile(String u) {
        String p = u;
        if (p.startsWith("file://")) p = p.substring(7);
        if (p.indexOf('%') >= 0) { try { p = java.net.URLDecoder.decode(p, "UTF-8"); } catch (Exception ignored) {} }
        return new File(p);
    }
    private byte[] readAll(InputStream in) throws Exception {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        byte[] buf = new byte[65536]; int r;
        while ((r = in.read(buf)) > 0) o.write(buf, 0, r);
        in.close(); return o.toByteArray();
    }
}
