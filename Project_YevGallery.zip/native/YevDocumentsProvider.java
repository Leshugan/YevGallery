package leshugan.yg;

import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Point;
import android.os.Build;
import android.os.CancellationSignal;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.DocumentsContract.Document;
import android.provider.DocumentsContract.Root;
import android.provider.DocumentsProvider;
import android.webkit.MimeTypeMap;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.ArrayDeque;

/**
 * Делает YevGallery источником фото и видео в системных пикерах
 * («Из ваших приложений», «Открыть», «Сохранить в…»).
 * Корень — внутренняя память; показываются папки и только медиафайлы.
 */
public class YevDocumentsProvider extends DocumentsProvider {

    private static final String ROOT_ID = "root";

    private static final String[] DEFAULT_ROOT_PROJECTION = new String[]{
            Root.COLUMN_ROOT_ID, Root.COLUMN_MIME_TYPES, Root.COLUMN_FLAGS,
            Root.COLUMN_ICON, Root.COLUMN_TITLE, Root.COLUMN_SUMMARY,
            Root.COLUMN_DOCUMENT_ID, Root.COLUMN_AVAILABLE_BYTES
    };
    private static final String[] DEFAULT_DOCUMENT_PROJECTION = new String[]{
            Document.COLUMN_DOCUMENT_ID, Document.COLUMN_MIME_TYPE, Document.COLUMN_DISPLAY_NAME,
            Document.COLUMN_LAST_MODIFIED, Document.COLUMN_FLAGS, Document.COLUMN_SIZE
    };

    private File baseDir;

    @Override
    public boolean onCreate() {
        baseDir = Environment.getExternalStorageDirectory();
        return true;
    }

    @Override
    public Cursor queryRoots(String[] projection) {
        MatrixCursor result = new MatrixCursor(projection != null ? projection : DEFAULT_ROOT_PROJECTION);
        final MatrixCursor.RowBuilder row = result.newRow();
        row.add(Root.COLUMN_ROOT_ID, ROOT_ID);
        row.add(Root.COLUMN_SUMMARY, "Фото и видео");
        row.add(Root.COLUMN_FLAGS, Root.FLAG_SUPPORTS_CREATE | Root.FLAG_SUPPORTS_IS_CHILD | Root.FLAG_LOCAL_ONLY | Root.FLAG_SUPPORTS_SEARCH);
        row.add(Root.COLUMN_TITLE, "YevGallery");
        row.add(Root.COLUMN_DOCUMENT_ID, ROOT_ID);
        row.add(Root.COLUMN_MIME_TYPES, "image/*\nvideo/*");
        try { row.add(Root.COLUMN_AVAILABLE_BYTES, baseDir.getFreeSpace()); } catch (Throwable t) { row.add(Root.COLUMN_AVAILABLE_BYTES, 0); }
        row.add(Root.COLUMN_ICON, getContext().getApplicationInfo().icon);
        return result;
    }

    @Override
    public Cursor queryDocument(String documentId, String[] projection) throws FileNotFoundException {
        MatrixCursor result = new MatrixCursor(projection != null ? projection : DEFAULT_DOCUMENT_PROJECTION);
        includeFile(result, documentId, null);
        return result;
    }

    @Override
    public Cursor queryChildDocuments(String parentDocumentId, String[] projection, String sortOrder) throws FileNotFoundException {
        MatrixCursor result = new MatrixCursor(projection != null ? projection : DEFAULT_DOCUMENT_PROJECTION);
        final File parent = fileForDocId(parentDocumentId);
        File[] kids = parent.listFiles();
        if (kids != null) for (File f : kids) {
            if (!show(f)) continue;
            includeFile(result, docIdFor(f), f);
        }
        return result;
    }

    // папки — все обычные; файлы — только фото и видео
    private boolean show(File f) {
        String n = f.getName();
        if (n.startsWith(".")) return false;
        if (f.isDirectory()) return true;
        String m = getMimeType(f);
        return m.startsWith("image/") || m.startsWith("video/");
    }

    @Override
    public Cursor querySearchDocuments(String rootId, String query, String[] projection) throws FileNotFoundException {
        MatrixCursor result = new MatrixCursor(projection != null ? projection : DEFAULT_DOCUMENT_PROJECTION);
        final String q = query == null ? "" : query.toLowerCase();
        ArrayDeque<File> queue = new ArrayDeque<>();
        queue.add(baseDir);
        int found = 0;
        long deadline = System.currentTimeMillis() + 8000;   // системное окно не должно висеть
        while (!queue.isEmpty() && found < 200 && System.currentTimeMillis() < deadline) {
            File dir = queue.poll();
            File[] kids = dir.listFiles();
            if (kids == null) continue;
            for (File f : kids) {
                if (!show(f)) continue;
                if (f.isDirectory()) { queue.add(f); continue; }
                if (f.getName().toLowerCase().contains(q)) {
                    try { includeFile(result, docIdFor(f), f); found++; } catch (Exception ignored) {}
                    if (found >= 200) break;
                }
            }
        }
        return result;
    }

    @Override
    public AssetFileDescriptor openDocumentThumbnail(String documentId, Point sizeHint, CancellationSignal signal) throws FileNotFoundException {
        File f = fileForDocId(documentId);
        String mime = getMimeType(f);
        try {
            int w = sizeHint != null && sizeHint.x > 0 ? sizeHint.x : 256;
            int h = sizeHint != null && sizeHint.y > 0 ? sizeHint.y : 256;
            File cacheDir = new File(getContext().getCacheDir(), "safthumb");
            if (!cacheDir.exists()) cacheDir.mkdirs();
            File out = new File(cacheDir, Integer.toHexString((f.getAbsolutePath() + "|" + f.lastModified() + "|" + f.length()).hashCode()) + ".jpg");
            if (!out.exists() || out.length() == 0) {
                Bitmap bmp = null;
                if (mime.startsWith("image/")) {
                    BitmapFactory.Options o = new BitmapFactory.Options();
                    o.inJustDecodeBounds = true;
                    BitmapFactory.decodeFile(f.getAbsolutePath(), o);
                    int scale = 1;
                    while (o.outWidth / (scale * 2) >= w && o.outHeight / (scale * 2) >= h) scale *= 2;
                    BitmapFactory.Options o2 = new BitmapFactory.Options();
                    o2.inSampleSize = scale;
                    bmp = BitmapFactory.decodeFile(f.getAbsolutePath(), o2);
                } else if (mime.startsWith("video/")) {
                    android.media.MediaMetadataRetriever mmr = new android.media.MediaMetadataRetriever();
                    try {
                        mmr.setDataSource(f.getAbsolutePath());
                        if (Build.VERSION.SDK_INT >= 27) bmp = mmr.getScaledFrameAtTime(1000000, android.media.MediaMetadataRetriever.OPTION_CLOSEST_SYNC, w, h);
                        if (bmp == null) bmp = mmr.getFrameAtTime(1000000, android.media.MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
                    } finally { try { mmr.release(); } catch (Exception ignored) {} }
                }
                if (bmp == null) throw new FileNotFoundException("нет превью");
                FileOutputStream fos = new FileOutputStream(out);
                try { bmp.compress(Bitmap.CompressFormat.JPEG, 82, fos); } finally { fos.close(); bmp.recycle(); }
            }
            return new AssetFileDescriptor(ParcelFileDescriptor.open(out, ParcelFileDescriptor.MODE_READ_ONLY), 0, AssetFileDescriptor.UNKNOWN_LENGTH);
        } catch (FileNotFoundException e) { throw e; }
        catch (Exception e) { throw new FileNotFoundException("нет превью: " + e.getMessage()); }
    }

    @Override
    public ParcelFileDescriptor openDocument(String documentId, String mode, CancellationSignal signal) throws FileNotFoundException {
        final File file = fileForDocId(documentId);
        final int accessMode = ParcelFileDescriptor.parseMode(mode);
        return ParcelFileDescriptor.open(file, accessMode);
    }

    @Override
    public String createDocument(String parentDocumentId, String mimeType, String displayName) throws FileNotFoundException {
        File parent = fileForDocId(parentDocumentId);
        File f = new File(parent, displayName);
        try {
            if (Document.MIME_TYPE_DIR.equals(mimeType)) {
                if (!f.mkdir()) throw new FileNotFoundException("Не удалось создать папку " + f);
            } else {
                int n = 0; String base = displayName, ext = "";
                int dot = displayName.lastIndexOf('.');
                if (dot > 0) { base = displayName.substring(0, dot); ext = displayName.substring(dot); }
                while (f.exists()) { n++; f = new File(parent, base + " (" + n + ")" + ext); }
                if (!f.createNewFile()) throw new FileNotFoundException("Не удалось создать файл " + f);
            }
        } catch (Exception e) { throw new FileNotFoundException("Ошибка создания: " + e.getMessage()); }
        return docIdFor(f);
    }

    @Override
    public void deleteDocument(String documentId) throws FileNotFoundException {
        File f = fileForDocId(documentId);
        if (!f.delete()) throw new FileNotFoundException("Не удалось удалить " + documentId);
    }

    @Override
    public String renameDocument(String documentId, String displayName) throws FileNotFoundException {
        File f = fileForDocId(documentId);
        File target = new File(f.getParentFile(), displayName);
        if (!f.renameTo(target)) throw new FileNotFoundException("Не удалось переименовать " + documentId);
        return docIdFor(target);
    }

    @Override
    public boolean isChildDocument(String parentDocumentId, String documentId) {
        return documentId.startsWith(parentDocumentId);
    }

    private void includeFile(MatrixCursor result, String docId, File file) throws FileNotFoundException {
        if (file == null) file = fileForDocId(docId);
        int flags = 0;
        if (file.isDirectory()) {
            if (file.canWrite()) flags |= Document.FLAG_DIR_SUPPORTS_CREATE;
        } else if (file.canWrite()) {
            flags |= Document.FLAG_SUPPORTS_WRITE;
        }
        if (file.getParentFile() != null && file.getParentFile().canWrite())
            flags |= Document.FLAG_SUPPORTS_DELETE | Document.FLAG_SUPPORTS_RENAME;

        final String displayName = file.getName();
        final String mimeType = getMimeType(file);
        if (mimeType.startsWith("image/") || mimeType.startsWith("video/")) flags |= Document.FLAG_SUPPORTS_THUMBNAIL;

        final MatrixCursor.RowBuilder row = result.newRow();
        row.add(Document.COLUMN_DOCUMENT_ID, docId);
        row.add(Document.COLUMN_DISPLAY_NAME, displayName.isEmpty() ? "YevGallery" : displayName);
        row.add(Document.COLUMN_SIZE, file.length());
        row.add(Document.COLUMN_MIME_TYPE, mimeType);
        row.add(Document.COLUMN_LAST_MODIFIED, file.lastModified());
        row.add(Document.COLUMN_FLAGS, flags);
    }

    // id документа: "root:<путь внутри хранилища>"
    private String docIdFor(File file) {
        String path = file.getAbsolutePath(), root = baseDir.getAbsolutePath();
        if (path.equals(root)) return ROOT_ID;
        if (path.startsWith(root + "/")) return ROOT_ID + ":" + path.substring(root.length() + 1);
        return ROOT_ID;
    }

    private File fileForDocId(String docId) throws FileNotFoundException {
        if (docId == null) return baseDir;
        int c = docId.indexOf(':');
        if (c < 0) return baseDir;
        String rel = docId.substring(c + 1);
        return rel.isEmpty() ? baseDir : new File(baseDir, rel);
    }

    private static String getMimeType(File file) {
        if (file.isDirectory()) return Document.MIME_TYPE_DIR;
        String name = file.getName();
        int dot = name.lastIndexOf('.');
        if (dot >= 0) {
            String ext = name.substring(dot + 1).toLowerCase();
            String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
            if (m != null) return m;
        }
        return "application/octet-stream";
    }
}
