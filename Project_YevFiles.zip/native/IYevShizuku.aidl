// Служба внутри процесса Shizuku. Номера транзакций обязательны у ВСЕХ методов,
// если задан хоть один; destroy() с этим номером требует сам Shizuku — не менять.
package leshugan.fm;

interface IYevShizuku {
    String list(String path) = 1;
    boolean mkdirs(String path) = 2;
    boolean delete(String path) = 3;
    boolean rename(String from, String to) = 4;
    ParcelFileDescriptor open(String path, String mode) = 5;
    void destroy() = 16777114;
}
